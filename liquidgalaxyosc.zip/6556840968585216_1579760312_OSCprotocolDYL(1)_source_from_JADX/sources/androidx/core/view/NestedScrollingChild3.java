package androidx.core.view;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public interface NestedScrollingChild3 extends NestedScrollingChild2 {
    void dispatchNestedScroll(int i, int i2, int i3, int i4, @Nullable int[] iArr, int i5, @NonNull int[] iArr2);
}
